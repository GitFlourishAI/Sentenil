import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const sectors = pgTable("sectors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  color: text("color").notNull(),
});

export const portfolioPositions = pgTable("portfolio_positions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticker: text("ticker").notNull(),
  companyName: text("company_name").notNull(),
  sectorId: varchar("sector_id").notNull(),
  weight: real("weight").notNull(),
  shares: integer("shares").notNull(),
  avgCost: real("avg_cost").notNull(),
  currentPrice: real("current_price").notNull(),
  marketValue: real("market_value").notNull(),
  pnl: real("pnl").notNull(),
  pnlPercent: real("pnl_percent").notNull(),
  beta: real("beta").notNull(),
  region: text("region").notNull(),
  currency: text("currency").notNull(),
});

export const catalysts = pgTable("catalysts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  sectorId: varchar("sector_id").notNull(),
  sourceType: text("source_type").notNull(),
  sourceName: text("source_name").notNull(),
  sourceUrl: text("source_url"),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  timeHorizon: text("time_horizon").notNull(),
  confidenceScore: real("confidence_score").notNull(),
  impactMagnitude: real("impact_magnitude").notNull(),
  impactDirection: text("impact_direction").notNull(),
  status: text("status").notNull().default("active"),
  shockType: text("shock_type").notNull(),
  evidenceSummary: text("evidence_summary").notNull(),
});

export const financialImpacts = pgTable("financial_impacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  catalystId: varchar("catalyst_id").notNull(),
  positionId: varchar("position_id").notNull(),
  revenueImpact: real("revenue_impact"),
  revenueDirection: text("revenue_direction"),
  costImpact: real("cost_impact"),
  costDirection: text("cost_direction"),
  ebitdaImpact: real("ebitda_impact"),
  ebitdaDirection: text("ebitda_direction"),
  capexImpact: real("capex_impact"),
  capexDirection: text("capex_direction"),
  workingCapitalImpact: real("working_capital_impact"),
  workingCapitalDirection: text("working_capital_direction"),
  debtImpact: real("debt_impact"),
  debtDirection: text("debt_direction"),
  leverageImpact: real("leverage_impact"),
  leverageDirection: text("leverage_direction"),
  valuationDelta: real("valuation_delta"),
  evEbitdaBase: real("ev_ebitda_base"),
  evEbitdaStressed: real("ev_ebitda_stressed"),
  equityDelta: real("equity_delta"),
  materialityLevel: text("materiality_level").notNull(),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  catalystId: varchar("catalyst_id").notNull(),
  positionId: varchar("position_id"),
  type: text("type").notNull(),
  severity: text("severity").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  isDismissed: boolean("is_dismissed").notNull().default(false),
  triggeredAt: timestamp("triggered_at").notNull().defaultNow(),
  thresholdValue: real("threshold_value"),
  actualValue: real("actual_value"),
  action: text("action"),
});

export const insertUserSchema = createInsertSchema(users).pick({ username: true, password: true });
export const insertSectorSchema = createInsertSchema(sectors).omit({ id: true });
export const insertPositionSchema = createInsertSchema(portfolioPositions).omit({ id: true });
export const insertCatalystSchema = createInsertSchema(catalysts).omit({ id: true });
export const insertFinancialImpactSchema = createInsertSchema(financialImpacts).omit({ id: true });
export const insertAlertSchema = createInsertSchema(alerts).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Sector = typeof sectors.$inferSelect;
export type InsertSector = z.infer<typeof insertSectorSchema>;
export type PortfolioPosition = typeof portfolioPositions.$inferSelect;
export type InsertPortfolioPosition = z.infer<typeof insertPositionSchema>;
export type Catalyst = typeof catalysts.$inferSelect;
export type InsertCatalyst = z.infer<typeof insertCatalystSchema>;
export type FinancialImpact = typeof financialImpacts.$inferSelect;
export type InsertFinancialImpact = z.infer<typeof insertFinancialImpactSchema>;
export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
