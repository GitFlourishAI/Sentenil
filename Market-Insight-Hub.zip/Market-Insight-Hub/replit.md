# SENTINEL - Sector Intelligence Platform

## Overview
A sector-aware intelligence platform for family offices that monitors portfolio risk and captures alpha through real-time catalyst detection. Fund managers can make buy/sell/hedge decisions within a 3-6 month time horizon.

## Architecture
- **Frontend**: React + TypeScript + TanStack Query + Recharts + Wouter + Shadcn UI
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with institutional dark theme (Bloomberg/Palantir inspired)

## Key Pages
- `/` - Dashboard (Command Center) - Portfolio metrics, top catalysts, sector exposure, financial impact charts, recent alerts, top movers
- `/catalysts` - Catalyst Intelligence - Ranked catalysts with search/filter, expandable detail with evidence summary, affected positions, financial impact breakdown
- `/portfolio` - Portfolio Monitor - Position table/treemap views, sector weights, regional exposure, valuation deltas
- `/alerts` - Alert Center - Threshold-based alerts with severity levels, mark read/dismiss functionality, action recommendations

## Data Model
- `sectors` - Industry sectors with color coding
- `portfolio_positions` - Stock positions with weights, P&L, beta, region
- `catalysts` - Detected market events/shocks with confidence scores and impact magnitude
- `financial_impacts` - Line-item financial impact per catalyst per position (revenue, costs, EBITDA, capex, debt, leverage, valuation delta)
- `alerts` - Threshold-based notifications with severity and recommended actions

## API Endpoints
- `GET /api/sectors` - All sectors
- `GET /api/positions` - All portfolio positions
- `GET /api/catalysts` - All catalysts
- `GET /api/financial-impacts` - All financial impacts
- `GET /api/financial-impacts/catalyst/:catalystId` - Impacts by catalyst
- `GET /api/alerts` - All alerts
- `PATCH /api/alerts/:id/read` - Mark alert as read
- `PATCH /api/alerts/:id/dismiss` - Dismiss alert

## Design Tokens
- Primary: #0A1F44 (deep navy background), Accent: #00D4FF (cyan), Success: #3FB950, Warning: #D29922, Critical: #F85149
- Fonts: Inter (sans), SF Mono/JetBrains Mono (monospace)
- Dark mode institutional interface with dense data tables
