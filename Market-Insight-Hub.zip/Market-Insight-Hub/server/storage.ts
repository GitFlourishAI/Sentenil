import { db } from "./db";
import { eq } from "drizzle-orm";
import {
  users, sectors, portfolioPositions, catalysts, financialImpacts, alerts,
  type User, type InsertUser,
  type Sector, type InsertSector,
  type PortfolioPosition, type InsertPortfolioPosition,
  type Catalyst, type InsertCatalyst,
  type FinancialImpact, type InsertFinancialImpact,
  type Alert, type InsertAlert,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getAllSectors(): Promise<Sector[]>;
  createSector(sector: InsertSector): Promise<Sector>;

  getAllPositions(): Promise<PortfolioPosition[]>;
  createPosition(position: InsertPortfolioPosition): Promise<PortfolioPosition>;

  getAllCatalysts(): Promise<Catalyst[]>;
  createCatalyst(catalyst: InsertCatalyst): Promise<Catalyst>;

  getAllFinancialImpacts(): Promise<FinancialImpact[]>;
  getFinancialImpactsByCatalyst(catalystId: string): Promise<FinancialImpact[]>;
  createFinancialImpact(impact: InsertFinancialImpact): Promise<FinancialImpact>;

  getAllAlerts(): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertRead(id: string): Promise<Alert | undefined>;
  dismissAlert(id: string): Promise<Alert | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async getAllSectors(): Promise<Sector[]> {
    return db.select().from(sectors);
  }

  async createSector(sector: InsertSector): Promise<Sector> {
    const [created] = await db.insert(sectors).values(sector).returning();
    return created;
  }

  async getAllPositions(): Promise<PortfolioPosition[]> {
    return db.select().from(portfolioPositions);
  }

  async createPosition(position: InsertPortfolioPosition): Promise<PortfolioPosition> {
    const [created] = await db.insert(portfolioPositions).values(position).returning();
    return created;
  }

  async getAllCatalysts(): Promise<Catalyst[]> {
    return db.select().from(catalysts);
  }

  async createCatalyst(catalyst: InsertCatalyst): Promise<Catalyst> {
    const [created] = await db.insert(catalysts).values(catalyst).returning();
    return created;
  }

  async getAllFinancialImpacts(): Promise<FinancialImpact[]> {
    return db.select().from(financialImpacts);
  }

  async getFinancialImpactsByCatalyst(catalystId: string): Promise<FinancialImpact[]> {
    return db.select().from(financialImpacts).where(eq(financialImpacts.catalystId, catalystId));
  }

  async createFinancialImpact(impact: InsertFinancialImpact): Promise<FinancialImpact> {
    const [created] = await db.insert(financialImpacts).values(impact).returning();
    return created;
  }

  async getAllAlerts(): Promise<Alert[]> {
    return db.select().from(alerts);
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [created] = await db.insert(alerts).values(alert).returning();
    return created;
  }

  async markAlertRead(id: string): Promise<Alert | undefined> {
    const [updated] = await db.update(alerts).set({ isRead: true }).where(eq(alerts.id, id)).returning();
    return updated;
  }

  async dismissAlert(id: string): Promise<Alert | undefined> {
    const [updated] = await db.update(alerts).set({ isDismissed: true }).where(eq(alerts.id, id)).returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
