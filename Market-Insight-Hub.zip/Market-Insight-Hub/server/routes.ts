import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/sectors", async (_req, res) => {
    const sectors = await storage.getAllSectors();
    res.json(sectors);
  });

  app.get("/api/positions", async (_req, res) => {
    const positions = await storage.getAllPositions();
    res.json(positions);
  });

  app.get("/api/catalysts", async (_req, res) => {
    const catalysts = await storage.getAllCatalysts();
    res.json(catalysts);
  });

  app.get("/api/financial-impacts", async (_req, res) => {
    const impacts = await storage.getAllFinancialImpacts();
    res.json(impacts);
  });

  app.get("/api/financial-impacts/catalyst/:catalystId", async (req, res) => {
    const impacts = await storage.getFinancialImpactsByCatalyst(req.params.catalystId);
    res.json(impacts);
  });

  app.get("/api/alerts", async (_req, res) => {
    const alerts = await storage.getAllAlerts();
    res.json(alerts);
  });

  app.patch("/api/alerts/:id/read", async (req, res) => {
    const alert = await storage.markAlertRead(req.params.id);
    if (!alert) return res.status(404).json({ message: "Alert not found" });
    res.json(alert);
  });

  app.patch("/api/alerts/:id/dismiss", async (req, res) => {
    const alert = await storage.dismissAlert(req.params.id);
    if (!alert) return res.status(404).json({ message: "Alert not found" });
    res.json(alert);
  });

  return httpServer;
}
