import { db } from "./db";
import { sectors, portfolioPositions, catalysts, financialImpacts, alerts } from "@shared/schema";
import { sql } from "drizzle-orm";

export async function seedDatabase() {
  const existingSectors = await db.select().from(sectors);
  if (existingSectors.length > 0) return;

  console.log("Seeding database with realistic financial data...");

  const sectorData = [
    { name: "Technology", color: "#00D4FF" },
    { name: "Energy", color: "#3FB950" },
    { name: "Financials", color: "#D29922" },
    { name: "Healthcare", color: "#F85149" },
    { name: "Industrials", color: "#6E40C9" },
    { name: "Consumer Discretionary", color: "#8B949E" },
  ];

  const createdSectors = [];
  for (const s of sectorData) {
    const [created] = await db.insert(sectors).values(s).returning();
    createdSectors.push(created);
  }

  const positionData = [
    { ticker: "AAPL", companyName: "Apple Inc.", sectorId: createdSectors[0].id, weight: 12.5, shares: 15000, avgCost: 162.30, currentPrice: 178.72, marketValue: 2680800, pnl: 246300, pnlPercent: 10.12, beta: 1.21, region: "North America", currency: "USD" },
    { ticker: "MSFT", companyName: "Microsoft Corp.", sectorId: createdSectors[0].id, weight: 11.2, shares: 8000, avgCost: 310.50, currentPrice: 338.11, marketValue: 2704880, pnl: 220880, pnlPercent: 8.89, beta: 0.93, region: "North America", currency: "USD" },
    { ticker: "NVDA", companyName: "NVIDIA Corp.", sectorId: createdSectors[0].id, weight: 9.8, shares: 5500, avgCost: 380.20, currentPrice: 422.50, marketValue: 2323750, pnl: 232650, pnlPercent: 11.13, beta: 1.68, region: "North America", currency: "USD" },
    { ticker: "XOM", companyName: "Exxon Mobil Corp.", sectorId: createdSectors[1].id, weight: 7.5, shares: 18000, avgCost: 95.40, currentPrice: 104.82, marketValue: 1886760, pnl: 169560, pnlPercent: 9.87, beta: 0.89, region: "North America", currency: "USD" },
    { ticker: "CVX", companyName: "Chevron Corp.", sectorId: createdSectors[1].id, weight: 5.8, shares: 10000, avgCost: 148.20, currentPrice: 155.30, marketValue: 1553000, pnl: 71000, pnlPercent: 4.79, beta: 1.05, region: "North America", currency: "USD" },
    { ticker: "JPM", companyName: "JPMorgan Chase & Co.", sectorId: createdSectors[2].id, weight: 8.3, shares: 12000, avgCost: 155.80, currentPrice: 168.40, marketValue: 2020800, pnl: 151200, pnlPercent: 8.09, beta: 1.12, region: "North America", currency: "USD" },
    { ticker: "GS", companyName: "Goldman Sachs Group", sectorId: createdSectors[2].id, weight: 5.2, shares: 4000, avgCost: 338.50, currentPrice: 362.10, marketValue: 1448400, pnl: 94400, pnlPercent: 6.97, beta: 1.35, region: "North America", currency: "USD" },
    { ticker: "JNJ", companyName: "Johnson & Johnson", sectorId: createdSectors[3].id, weight: 6.1, shares: 10000, avgCost: 158.90, currentPrice: 152.30, marketValue: 1523000, pnl: -66000, pnlPercent: -4.15, beta: 0.54, region: "North America", currency: "USD" },
    { ticker: "PFE", companyName: "Pfizer Inc.", sectorId: createdSectors[3].id, weight: 4.2, shares: 35000, avgCost: 30.50, currentPrice: 28.15, marketValue: 985250, pnl: -82250, pnlPercent: -7.70, beta: 0.67, region: "North America", currency: "USD" },
    { ticker: "CAT", companyName: "Caterpillar Inc.", sectorId: createdSectors[4].id, weight: 5.5, shares: 5000, avgCost: 248.30, currentPrice: 268.90, marketValue: 1344500, pnl: 103000, pnlPercent: 8.30, beta: 1.08, region: "North America", currency: "USD" },
    { ticker: "BA", companyName: "Boeing Co.", sectorId: createdSectors[4].id, weight: 4.8, shares: 6500, avgCost: 195.40, currentPrice: 178.20, marketValue: 1158300, pnl: -111800, pnlPercent: -8.80, beta: 1.42, region: "North America", currency: "USD" },
    { ticker: "TSLA", companyName: "Tesla Inc.", sectorId: createdSectors[5].id, weight: 7.2, shares: 8000, avgCost: 215.60, currentPrice: 242.80, marketValue: 1942400, pnl: 217600, pnlPercent: 12.61, beta: 2.05, region: "North America", currency: "USD" },
    { ticker: "BABA", companyName: "Alibaba Group", sectorId: createdSectors[0].id, weight: 3.8, shares: 12000, avgCost: 82.40, currentPrice: 75.60, marketValue: 907200, pnl: -81600, pnlPercent: -8.25, beta: 0.78, region: "Asia Pacific", currency: "USD" },
    { ticker: "SHEL", companyName: "Shell PLC", sectorId: createdSectors[1].id, weight: 4.1, shares: 15000, avgCost: 62.80, currentPrice: 67.40, marketValue: 1011000, pnl: 69000, pnlPercent: 7.32, beta: 0.82, region: "Europe", currency: "USD" },
    { ticker: "HSBC", companyName: "HSBC Holdings", sectorId: createdSectors[2].id, weight: 4.0, shares: 22000, avgCost: 39.50, currentPrice: 42.20, marketValue: 928400, pnl: 59400, pnlPercent: 6.84, beta: 0.91, region: "Europe", currency: "USD" },
  ];

  const createdPositions = [];
  for (const p of positionData) {
    const [created] = await db.insert(portfolioPositions).values(p).returning();
    createdPositions.push(created);
  }

  const catalystData = [
    {
      title: "Fed Rate Decision: 50bp Cut Expected",
      description: "Federal Reserve signals aggressive easing cycle with potential 50bp rate cut amid cooling labor market data and declining inflation. Bond yields falling sharply across the curve.",
      sectorId: createdSectors[2].id,
      sourceType: "macro",
      sourceName: "Federal Reserve",
      sourceUrl: "https://federalreserve.gov/monetarypolicy",
      timeHorizon: "3M",
      confidenceScore: 0.92,
      impactMagnitude: 8.5,
      impactDirection: "positive",
      status: "active",
      shockType: "Monetary Policy",
      evidenceSummary: "Fed Chair commentary at Jackson Hole indicated strong bias toward rate cuts. CME FedWatch pricing 85% probability of 50bp cut. 2-year Treasury yield declined 25bp in response. Goldman Sachs and JPMorgan analysts both forecasting aggressive easing cycle through Q2 2026.",
    },
    {
      title: "China CNY Depreciation Accelerates",
      description: "PBoC allows CNY to weaken past 7.35 against USD, signaling tolerance for further depreciation. Direct impact on export-oriented tech manufacturers and commodity importers.",
      sectorId: createdSectors[0].id,
      sourceType: "fx",
      sourceName: "PBoC / Bloomberg",
      sourceUrl: "https://bloomberg.com/markets/currencies",
      timeHorizon: "6M",
      confidenceScore: 0.85,
      impactMagnitude: -6.2,
      impactDirection: "negative",
      status: "active",
      shockType: "Currency Shock",
      evidenceSummary: "CNY/USD breached 7.35 support level. PBoC daily fix consistently weaker than market expectations for 8 consecutive sessions. Capital outflows from Chinese tech sector accelerating. Import costs for Chinese companies rising, pressuring margins for firms with USD-denominated costs.",
    },
    {
      title: "EU Carbon Border Tax Implementation",
      description: "EU CBAM full implementation begins affecting industrial and energy sector imports. Steel, aluminum, and cement manufacturers face significant cost increases for EU market access.",
      sectorId: createdSectors[4].id,
      sourceType: "policy",
      sourceName: "European Commission",
      sourceUrl: null,
      timeHorizon: "6M",
      confidenceScore: 0.88,
      impactMagnitude: -4.8,
      impactDirection: "negative",
      status: "active",
      shockType: "Regulatory",
      evidenceSummary: "EU CBAM Phase 2 implementation confirmed with full carbon pricing for imported goods. Industrial producers outside EU face 15-25% cost increase on exports to European markets. Caterpillar and Boeing both have significant EU revenue exposure. Independent analysis by Wood Mackenzie confirms material EBITDA headwind for exposed firms.",
    },
    {
      title: "AI Semiconductor Demand Surge Q4",
      description: "Datacenter GPU demand exceeding supply by 3:1 ratio. NVIDIA, AMD, and TSMC all raising revenue guidance. Enterprise AI capex budgets expanding 40%+ YoY.",
      sectorId: createdSectors[0].id,
      sourceType: "earnings",
      sourceName: "NVIDIA Earnings Call",
      sourceUrl: null,
      timeHorizon: "3M",
      confidenceScore: 0.94,
      impactMagnitude: 12.3,
      impactDirection: "positive",
      status: "active",
      shockType: "Demand Shock",
      evidenceSummary: "NVIDIA Q3 revenue beat estimates by 22%. Data center revenue up 154% YoY. Microsoft, Google, Amazon all announced expanded AI infrastructure spending. Channel checks confirm GPU allocation waitlists extending through Q2 2026. Morgan Stanley raised NVDA price target 35%.",
    },
    {
      title: "Oil Supply Disruption - Middle East",
      description: "Geopolitical tensions in Strait of Hormuz disrupting 20% of global oil transit. Brent crude spiking above $95/bbl with potential for further escalation.",
      sectorId: createdSectors[1].id,
      sourceType: "commodity",
      sourceName: "IEA / Reuters",
      sourceUrl: null,
      timeHorizon: "3M",
      confidenceScore: 0.78,
      impactMagnitude: 7.4,
      impactDirection: "positive",
      status: "active",
      shockType: "Supply Shock",
      evidenceSummary: "Naval incidents in Strait of Hormuz. Insurance premiums for tanker transit up 300%. IEA emergency report warns of potential 2M bbl/day supply disruption. Brent crude futures in steep backwardation. Energy sector analyst consensus shifting to $100+ oil price scenario.",
    },
    {
      title: "GLP-1 Drug Competition Intensifies",
      description: "Multiple pharmaceutical companies advancing GLP-1 receptor agonist candidates into Phase III trials, threatening Eli Lilly and Novo Nordisk market dominance.",
      sectorId: createdSectors[3].id,
      sourceType: "sector_news",
      sourceName: "BioPharma Dive",
      sourceUrl: null,
      timeHorizon: "6M",
      confidenceScore: 0.72,
      impactMagnitude: -5.1,
      impactDirection: "negative",
      status: "active",
      shockType: "Competition",
      evidenceSummary: "Pfizer, AstraZeneca, and Amgen all advancing oral GLP-1 candidates. Phase III data readouts expected Q1-Q2 2026. Analyst consensus suggests 15-20% market share erosion for incumbents by 2028. Healthcare sector valuations compressing on increased competition fears.",
    },
    {
      title: "US-China Tech Export Controls Expanded",
      description: "Commerce Department expanding semiconductor export restrictions to cover additional Chinese entities and technology nodes. Cloud computing services now included.",
      sectorId: createdSectors[0].id,
      sourceType: "policy",
      sourceName: "US Dept. of Commerce",
      sourceUrl: null,
      timeHorizon: "6M",
      confidenceScore: 0.82,
      impactMagnitude: -3.9,
      impactDirection: "negative",
      status: "active",
      shockType: "Regulatory",
      evidenceSummary: "New export control rules covering AI chips, EDA tools, and cloud computing services. Alibaba Cloud and other Chinese tech firms directly impacted. Estimated $8-12B annual revenue at risk for US semiconductor firms. NVIDIA and AMD both disclosed material China revenue exposure in filings.",
    },
    {
      title: "EV Subsidy Extension - US IRA",
      description: "Inflation Reduction Act EV tax credits extended through 2030 with expanded eligibility criteria. Positive for domestic EV manufacturers and battery supply chain.",
      sectorId: createdSectors[5].id,
      sourceType: "policy",
      sourceName: "US Congress",
      sourceUrl: null,
      timeHorizon: "6M",
      confidenceScore: 0.76,
      impactMagnitude: 4.2,
      impactDirection: "positive",
      status: "active",
      shockType: "Policy Tailwind",
      evidenceSummary: "Bipartisan agreement to extend $7,500 EV tax credit through 2030. Income eligibility limits raised. Used EV credit increased to $5,000. Tesla, GM, and Ford all qualify under domestic content requirements. UBS estimates additional 1.2M EV units sold annually from extended subsidies.",
    },
  ];

  const createdCatalysts = [];
  for (const c of catalystData) {
    const [created] = await db.insert(catalysts).values(c).returning();
    createdCatalysts.push(created);
  }

  const impactData = [
    { catalystId: createdCatalysts[0].id, positionId: createdPositions[5].id, revenueImpact: 3.2, revenueDirection: "positive", costImpact: -1.5, costDirection: "positive", ebitdaImpact: 4.8, ebitdaDirection: "positive", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: -2.1, debtDirection: "positive", leverageImpact: -0.3, leverageDirection: "positive", valuationDelta: 6.2, evEbitdaBase: 10.5, evEbitdaStressed: 11.2, equityDelta: 7.8, materialityLevel: "high" },
    { catalystId: createdCatalysts[0].id, positionId: createdPositions[6].id, revenueImpact: 5.1, revenueDirection: "positive", costImpact: -0.8, costDirection: "positive", ebitdaImpact: 6.2, ebitdaDirection: "positive", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: -3.0, debtDirection: "positive", leverageImpact: -0.5, leverageDirection: "positive", valuationDelta: 8.1, evEbitdaBase: 9.8, evEbitdaStressed: 10.6, equityDelta: 9.5, materialityLevel: "high" },
    { catalystId: createdCatalysts[1].id, positionId: createdPositions[12].id, revenueImpact: -8.5, revenueDirection: "negative", costImpact: 4.2, costDirection: "negative", ebitdaImpact: -12.1, ebitdaDirection: "negative", capexImpact: 2.1, capexDirection: "negative", workingCapitalImpact: 3.5, workingCapitalDirection: "negative", debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: -14.3, evEbitdaBase: 12.5, evEbitdaStressed: 10.7, equityDelta: -16.2, materialityLevel: "high" },
    { catalystId: createdCatalysts[2].id, positionId: createdPositions[9].id, revenueImpact: -2.1, revenueDirection: "negative", costImpact: 3.8, costDirection: "negative", ebitdaImpact: -5.4, ebitdaDirection: "negative", capexImpact: 1.2, capexDirection: "negative", workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: 0.4, leverageDirection: "negative", valuationDelta: -6.8, evEbitdaBase: 15.2, evEbitdaStressed: 14.1, equityDelta: -7.5, materialityLevel: "medium" },
    { catalystId: createdCatalysts[2].id, positionId: createdPositions[10].id, revenueImpact: -3.5, revenueDirection: "negative", costImpact: 5.2, costDirection: "negative", ebitdaImpact: -8.1, ebitdaDirection: "negative", capexImpact: 2.8, capexDirection: "negative", workingCapitalImpact: 1.5, workingCapitalDirection: "negative", debtImpact: 1.2, debtDirection: "negative", leverageImpact: 0.6, leverageDirection: "negative", valuationDelta: -9.4, evEbitdaBase: 18.5, evEbitdaStressed: 16.8, equityDelta: -10.2, materialityLevel: "high" },
    { catalystId: createdCatalysts[3].id, positionId: createdPositions[2].id, revenueImpact: 18.5, revenueDirection: "positive", costImpact: 2.1, costDirection: "negative", ebitdaImpact: 15.8, ebitdaDirection: "positive", capexImpact: 8.5, capexDirection: "negative", workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: 14.2, evEbitdaBase: 35.0, evEbitdaStressed: 40.0, equityDelta: 16.5, materialityLevel: "high" },
    { catalystId: createdCatalysts[3].id, positionId: createdPositions[0].id, revenueImpact: 4.2, revenueDirection: "positive", costImpact: 1.5, costDirection: "negative", ebitdaImpact: 3.1, ebitdaDirection: "positive", capexImpact: 5.2, capexDirection: "negative", workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: 3.8, evEbitdaBase: 28.5, evEbitdaStressed: 29.6, equityDelta: 4.2, materialityLevel: "medium" },
    { catalystId: createdCatalysts[4].id, positionId: createdPositions[3].id, revenueImpact: 12.4, revenueDirection: "positive", costImpact: -1.2, costDirection: "positive", ebitdaImpact: 14.8, ebitdaDirection: "positive", capexImpact: null, capexDirection: null, workingCapitalImpact: -2.5, workingCapitalDirection: "positive", debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: 9.6, evEbitdaBase: 6.8, evEbitdaStressed: 7.5, equityDelta: 11.2, materialityLevel: "high" },
    { catalystId: createdCatalysts[4].id, positionId: createdPositions[4].id, revenueImpact: 8.8, revenueDirection: "positive", costImpact: -0.5, costDirection: "positive", ebitdaImpact: 10.2, ebitdaDirection: "positive", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: 7.1, evEbitdaBase: 7.2, evEbitdaStressed: 7.8, equityDelta: 8.5, materialityLevel: "medium" },
    { catalystId: createdCatalysts[4].id, positionId: createdPositions[13].id, revenueImpact: 10.1, revenueDirection: "positive", costImpact: -0.8, costDirection: "positive", ebitdaImpact: 11.5, ebitdaDirection: "positive", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: 8.2, evEbitdaBase: 5.5, evEbitdaStressed: 6.0, equityDelta: 9.8, materialityLevel: "medium" },
    { catalystId: createdCatalysts[5].id, positionId: createdPositions[8].id, revenueImpact: -6.2, revenueDirection: "negative", costImpact: 2.8, costDirection: "negative", ebitdaImpact: -8.5, ebitdaDirection: "negative", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: -7.8, evEbitdaBase: 10.2, evEbitdaStressed: 9.4, equityDelta: -9.1, materialityLevel: "medium" },
    { catalystId: createdCatalysts[6].id, positionId: createdPositions[2].id, revenueImpact: -5.8, revenueDirection: "negative", costImpact: null, costDirection: null, ebitdaImpact: -5.2, ebitdaDirection: "negative", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: -4.5, evEbitdaBase: 35.0, evEbitdaStressed: 33.4, equityDelta: -5.2, materialityLevel: "medium" },
    { catalystId: createdCatalysts[6].id, positionId: createdPositions[12].id, revenueImpact: -12.5, revenueDirection: "negative", costImpact: null, costDirection: null, ebitdaImpact: -11.8, ebitdaDirection: "negative", capexImpact: null, capexDirection: null, workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: -10.2, evEbitdaBase: 12.5, evEbitdaStressed: 11.2, equityDelta: -11.8, materialityLevel: "high" },
    { catalystId: createdCatalysts[7].id, positionId: createdPositions[11].id, revenueImpact: 6.8, revenueDirection: "positive", costImpact: -1.2, costDirection: "positive", ebitdaImpact: 8.5, ebitdaDirection: "positive", capexImpact: 3.5, capexDirection: "negative", workingCapitalImpact: null, workingCapitalDirection: null, debtImpact: null, debtDirection: null, leverageImpact: null, leverageDirection: null, valuationDelta: 5.8, evEbitdaBase: 58.0, evEbitdaStressed: 61.4, equityDelta: 6.5, materialityLevel: "medium" },
  ];

  for (const i of impactData) {
    await db.insert(financialImpacts).values(i);
  }

  const alertData = [
    { catalystId: createdCatalysts[3].id, positionId: createdPositions[2].id, type: "impact_threshold", severity: "critical", title: "NVDA: Valuation delta exceeds 10%", message: "AI semiconductor demand catalyst driving +14.2% valuation sensitivity. Consider increasing position weight.", isRead: false, isDismissed: false, thresholdValue: 10.0, actualValue: 14.2, action: "Increase" },
    { catalystId: createdCatalysts[1].id, positionId: createdPositions[12].id, type: "impact_threshold", severity: "critical", title: "BABA: CNY depreciation driving -14.3% delta", message: "Currency shock creating material downside risk. Recommend hedging or trimming exposure.", isRead: false, isDismissed: false, thresholdValue: 10.0, actualValue: 14.3, action: "Hedge" },
    { catalystId: createdCatalysts[2].id, positionId: createdPositions[10].id, type: "impact_threshold", severity: "high", title: "BA: Carbon tax impact -9.4% valuation", message: "EU CBAM implementation creating EBITDA headwind for Boeing. Review EU revenue exposure.", isRead: false, isDismissed: false, thresholdValue: 5.0, actualValue: 9.4, action: "Trim" },
    { catalystId: createdCatalysts[4].id, positionId: createdPositions[3].id, type: "catalyst_detected", severity: "high", title: "XOM: Oil supply disruption tailwind", message: "Middle East tensions driving +9.6% upside catalyst for energy positions. Monitor escalation risk.", isRead: true, isDismissed: false, thresholdValue: 5.0, actualValue: 9.6, action: "Hold" },
    { catalystId: createdCatalysts[0].id, positionId: createdPositions[5].id, type: "catalyst_detected", severity: "medium", title: "JPM: Rate cut cycle positive for financials", message: "Fed easing cycle expected to boost net interest income and trading volumes for major banks.", isRead: true, isDismissed: false, thresholdValue: 5.0, actualValue: 6.2, action: "Increase" },
    { catalystId: createdCatalysts[5].id, positionId: createdPositions[8].id, type: "sector_shock", severity: "medium", title: "PFE: GLP-1 competition pressure", message: "Increased competition in GLP-1 space may erode Pfizer's market share. Confidence level moderate.", isRead: false, isDismissed: false, thresholdValue: 5.0, actualValue: 7.8, action: "Trim" },
    { catalystId: createdCatalysts[6].id, positionId: createdPositions[2].id, type: "regulatory", severity: "medium", title: "NVDA: Export control headwind", message: "Expanded US-China tech export controls may reduce China revenue by $8-12B. Net impact partially offset by AI demand.", isRead: false, isDismissed: false, thresholdValue: 3.0, actualValue: 4.5, action: "Monitor" },
    { catalystId: createdCatalysts[7].id, positionId: createdPositions[11].id, type: "policy_tailwind", severity: "low", title: "TSLA: EV subsidy extension positive", message: "IRA tax credit extension through 2030 supports domestic EV demand. Modest upside catalyst.", isRead: true, isDismissed: false, thresholdValue: 3.0, actualValue: 5.8, action: "Hold" },
  ];

  for (const a of alertData) {
    await db.insert(alerts).values(a);
  }

  console.log("Database seeded successfully!");
}
