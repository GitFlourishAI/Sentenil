import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface ImpactBadgeProps {
  direction: string;
  magnitude?: number;
  label?: string;
  className?: string;
}

export function ImpactBadge({ direction, magnitude, label, className }: ImpactBadgeProps) {
  const isPositive = direction === "positive" || direction === "+";
  const isNegative = direction === "negative" || direction === "-";

  return (
    <Badge
      variant="outline"
      className={cn(
        "font-mono text-[10px] gap-1",
        isPositive && "border-success/30 text-success bg-success/5",
        isNegative && "border-critical/30 text-critical bg-critical/5",
        !isPositive && !isNegative && "border-warning/30 text-warning bg-warning/5",
        className
      )}
    >
      {isPositive && "+"}{isNegative && "-"}
      {magnitude !== undefined && `${Math.abs(magnitude).toFixed(1)}%`}
      {label && ` ${label}`}
    </Badge>
  );
}

interface MaterialityBadgeProps {
  level: string;
  className?: string;
}

export function MaterialityBadge({ level, className }: MaterialityBadgeProps) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "font-mono text-[10px]",
        level === "high" && "border-critical/30 text-critical bg-critical/5",
        level === "medium" && "border-warning/30 text-warning bg-warning/5",
        level === "low" && "border-muted-foreground/30 text-muted-foreground bg-muted/5",
        className
      )}
    >
      {level.toUpperCase()}
    </Badge>
  );
}

interface ConfidenceBadgeProps {
  score: number;
  className?: string;
}

export function ConfidenceBadge({ score, className }: ConfidenceBadgeProps) {
  const pct = Math.round(score * 100);
  return (
    <Badge
      variant="outline"
      className={cn(
        "font-mono text-[10px]",
        pct >= 80 && "border-success/30 text-success bg-success/5",
        pct >= 60 && pct < 80 && "border-primary/30 text-primary bg-primary/5",
        pct < 60 && "border-muted-foreground/30 text-muted-foreground bg-muted/5",
        className
      )}
    >
      {pct}% CONF
    </Badge>
  );
}
