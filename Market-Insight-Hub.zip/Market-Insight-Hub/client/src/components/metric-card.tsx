import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface MetricCardProps {
  label: string;
  value: string;
  subValue?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  accentColor?: string;
  icon?: React.ReactNode;
  testId?: string;
}

export function MetricCard({
  label,
  value,
  subValue,
  trend,
  trendValue,
  accentColor,
  icon,
  testId,
}: MetricCardProps) {
  return (
    <Card
      className={cn("p-4 relative")}
      data-testid={testId}
    >
      {accentColor && (
        <div
          className="absolute top-0 left-0 right-0 h-[2px] rounded-t-md"
          style={{ background: accentColor }}
        />
      )}
      <div className="flex items-start justify-between gap-2 mb-2">
        <span className="text-[10px] font-mono tracking-wider text-muted-foreground uppercase">
          {label}
        </span>
        {icon && (
          <div className="text-muted-foreground">{icon}</div>
        )}
      </div>
      <div className="flex items-end gap-2">
        <span className="text-xl font-semibold tracking-tight text-foreground font-mono">
          {value}
        </span>
        {trend && trendValue && (
          <span
            className={cn(
              "text-xs font-mono flex items-center gap-0.5 mb-0.5",
              trend === "up" && "text-success",
              trend === "down" && "text-critical",
              trend === "neutral" && "text-muted-foreground"
            )}
          >
            {trend === "up" && <TrendingUp className="w-3 h-3" />}
            {trend === "down" && <TrendingDown className="w-3 h-3" />}
            {trend === "neutral" && <Minus className="w-3 h-3" />}
            {trendValue}
          </span>
        )}
      </div>
      {subValue && (
        <span className="text-xs text-muted-foreground font-mono mt-1 block">
          {subValue}
        </span>
      )}
    </Card>
  );
}
