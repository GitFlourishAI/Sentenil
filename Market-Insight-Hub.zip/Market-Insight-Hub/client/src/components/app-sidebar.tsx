import { useLocation, Link } from "wouter";
import {
  LayoutDashboard,
  Zap,
  Briefcase,
  Bell,
  Activity,
  Shield,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import type { Alert } from "@shared/schema";

const navItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Catalysts", url: "/catalysts", icon: Zap },
  { title: "Portfolio", url: "/portfolio", icon: Briefcase },
  { title: "Alerts", url: "/alerts", icon: Bell },
];

export function AppSidebar() {
  const [location] = useLocation();

  const { data: alerts } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const unreadCount = alerts?.filter((a) => !a.isRead && !a.isDismissed).length ?? 0;

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center glow-cyan">
            <Shield className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h1 className="text-sm font-semibold tracking-tight text-foreground" data-testid="text-app-name">
              SENTINEL
            </h1>
            <p className="text-[10px] font-mono text-muted-foreground tracking-wider">
              INTELLIGENCE PLATFORM
            </p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="pt-2">
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] font-mono tracking-widest text-muted-foreground px-4">
            NAVIGATION
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const isActive = location === item.url || 
                  (item.url !== "/" && location.startsWith(item.url));
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      data-active={isActive}
                      className="data-[active=true]:bg-sidebar-accent"
                    >
                      <Link href={item.url} data-testid={`link-nav-${item.title.toLowerCase()}`}>
                        <item.icon className={`w-4 h-4 ${isActive ? "text-primary" : ""}`} />
                        <span className="text-sm">{item.title}</span>
                        {item.title === "Alerts" && unreadCount > 0 && (
                          <Badge variant="destructive" className="ml-auto text-[10px] h-5 min-w-5 flex items-center justify-center">
                            {unreadCount}
                          </Badge>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] font-mono tracking-widest text-muted-foreground px-4">
            SYSTEM
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="px-4 py-2">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-3 h-3 text-success" />
                <span className="text-xs text-muted-foreground">System Active</span>
              </div>
              <div className="text-[10px] font-mono text-muted-foreground space-y-1">
                <div className="flex justify-between gap-1">
                  <span>Data Feed</span>
                  <span className="text-success">LIVE</span>
                </div>
                <div className="flex justify-between gap-1">
                  <span>Last Scan</span>
                  <span>2m ago</span>
                </div>
                <div className="flex justify-between gap-1">
                  <span>Engine</span>
                  <span className="text-primary">v2.4.1</span>
                </div>
              </div>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-border">
        <div className="text-[10px] font-mono text-muted-foreground">
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
            <span>All systems operational</span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
