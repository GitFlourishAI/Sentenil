import { cn } from "@/lib/utils";

interface StatusIndicatorProps {
  status: string;
  label?: string;
  className?: string;
}

export function StatusIndicator({ status, label, className }: StatusIndicatorProps) {
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div
        className={cn(
          "w-1.5 h-1.5 rounded-full",
          status === "active" && "bg-success animate-pulse",
          status === "monitoring" && "bg-primary animate-pulse",
          status === "resolved" && "bg-muted-foreground",
          status === "critical" && "bg-critical animate-pulse",
          status === "warning" && "bg-warning",
        )}
      />
      {label && (
        <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
          {label ?? status}
        </span>
      )}
    </div>
  );
}
