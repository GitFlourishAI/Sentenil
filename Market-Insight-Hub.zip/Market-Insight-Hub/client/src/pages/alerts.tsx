import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bell,
  BellOff,
  Check,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Shield,
  Clock,
  Eye,
  X,
} from "lucide-react";
import type { Alert, Catalyst, PortfolioPosition } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

function LoadingSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-20 rounded-md" />
        ))}
      </div>
      {[1, 2, 3, 4].map((i) => (
        <Skeleton key={i} className="h-24 rounded-md" />
      ))}
    </div>
  );
}

export default function AlertsPage() {
  const [severityFilter, setSeverityFilter] = useState("all");
  const [tab, setTab] = useState("active");
  const { toast } = useToast();

  const { data: alerts, isLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });
  const { data: catalysts } = useQuery<Catalyst[]>({
    queryKey: ["/api/catalysts"],
  });
  const { data: positions } = useQuery<PortfolioPosition[]>({
    queryKey: ["/api/positions"],
  });

  const markReadMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("PATCH", `/api/alerts/${id}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
  });

  const dismissMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("PATCH", `/api/alerts/${id}/dismiss`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({ title: "Alert dismissed" });
    },
  });

  if (isLoading) return <LoadingSkeleton />;

  const catalystMap = new Map(catalysts?.map((c) => [c.id, c]) ?? []);
  const positionMap = new Map(positions?.map((p) => [p.id, p]) ?? []);

  const activeAlerts = alerts?.filter((a) => !a.isDismissed) ?? [];
  const dismissedAlerts = alerts?.filter((a) => a.isDismissed) ?? [];
  const criticalCount = activeAlerts.filter((a) => a.severity === "critical").length;
  const highCount = activeAlerts.filter((a) => a.severity === "high").length;
  const unreadCount = activeAlerts.filter((a) => !a.isRead).length;

  let displayed = tab === "active" ? activeAlerts : dismissedAlerts;
  if (severityFilter !== "all") {
    displayed = displayed.filter((a) => a.severity === severityFilter);
  }

  displayed = [...displayed].sort((a, b) => {
    const severityOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    const diff = (severityOrder[a.severity] ?? 4) - (severityOrder[b.severity] ?? 4);
    if (diff !== 0) return diff;
    return new Date(b.triggeredAt).getTime() - new Date(a.triggeredAt).getTime();
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "text-critical bg-critical/10 border-critical/30";
      case "high": return "text-warning bg-warning/10 border-warning/30";
      case "medium": return "text-primary bg-primary/10 border-primary/30";
      default: return "text-muted-foreground bg-muted/10 border-muted/30";
    }
  };

  const getSeverityDot = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-critical animate-pulse";
      case "high": return "bg-warning";
      case "medium": return "bg-primary";
      default: return "bg-muted-foreground";
    }
  };

  const getActionColor = (action: string | null) => {
    if (!action) return "";
    switch (action.toLowerCase()) {
      case "sell": case "trim": return "text-critical";
      case "buy": case "increase": return "text-success";
      case "hedge": return "text-warning";
      default: return "text-primary";
    }
  };

  return (
    <div className="p-4 space-y-4 overflow-auto h-full scrollbar-thin" data-testid="page-alerts">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Alert Center</h2>
          <p className="text-xs text-muted-foreground font-mono">
            Automated threshold monitoring &middot; {unreadCount} unread
          </p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Card className="p-3 relative" data-testid="metric-critical-count">
          {criticalCount > 0 && <div className="absolute top-0 left-0 right-0 h-[2px] bg-critical rounded-t-md" />}
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-critical" />
            <span className="text-[10px] font-mono tracking-wider text-muted-foreground">CRITICAL</span>
          </div>
          <span className="text-2xl font-semibold font-mono text-foreground">{criticalCount}</span>
        </Card>
        <Card className="p-3 relative" data-testid="metric-high-count">
          {highCount > 0 && <div className="absolute top-0 left-0 right-0 h-[2px] bg-warning rounded-t-md" />}
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-4 h-4 text-warning" />
            <span className="text-[10px] font-mono tracking-wider text-muted-foreground">HIGH</span>
          </div>
          <span className="text-2xl font-semibold font-mono text-foreground">{highCount}</span>
        </Card>
        <Card className="p-3" data-testid="metric-unread-count">
          <div className="flex items-center gap-2 mb-1">
            <Bell className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-mono tracking-wider text-muted-foreground">UNREAD</span>
          </div>
          <span className="text-2xl font-semibold font-mono text-foreground">{unreadCount}</span>
        </Card>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="bg-muted/30">
            <TabsTrigger value="active" className="text-xs" data-testid="tab-active-alerts">
              Active ({activeAlerts.length})
            </TabsTrigger>
            <TabsTrigger value="dismissed" className="text-xs" data-testid="tab-dismissed-alerts">
              Dismissed ({dismissedAlerts.length})
            </TabsTrigger>
          </TabsList>
        </Tabs>
        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger className="w-36 bg-muted/30" data-testid="select-severity-filter">
            <SelectValue placeholder="All Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Severity</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        {displayed.map((alert, index) => {
          const catalyst = catalystMap.get(alert.catalystId);
          const position = alert.positionId ? positionMap.get(alert.positionId) : null;

          return (
            <Card
              key={alert.id}
              className={`p-4 ${!alert.isRead && !alert.isDismissed ? "border-l-2" : ""}`}
              style={!alert.isRead && !alert.isDismissed ? {
                borderLeftColor: alert.severity === "critical" ? "hsl(0, 72%, 51%)" :
                  alert.severity === "high" ? "hsl(38, 92%, 50%)" : "hsl(190, 100%, 50%)"
              } : undefined}
              data-testid={`card-alert-${index}`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${getSeverityDot(alert.severity)}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div>
                      <h3 className="text-sm font-semibold text-foreground">{alert.title}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">{alert.message}</p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {!alert.isDismissed && (
                        <>
                          {!alert.isRead && (
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => markReadMutation.mutate(alert.id)}
                              disabled={markReadMutation.isPending}
                              data-testid={`button-mark-read-${index}`}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => dismissMutation.mutate(alert.id)}
                            disabled={dismissMutation.isPending}
                            data-testid={`button-dismiss-${index}`}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <Badge variant="outline" className={`text-[10px] font-mono ${getSeverityColor(alert.severity)}`}>
                      {alert.severity.toUpperCase()}
                    </Badge>
                    <Badge variant="outline" className="text-[10px] font-mono text-muted-foreground">
                      {alert.type}
                    </Badge>
                    {position && (
                      <Badge variant="outline" className="text-[10px] font-mono text-primary">
                        {position.ticker}
                      </Badge>
                    )}
                    {alert.action && (
                      <Badge variant="outline" className={`text-[10px] font-mono font-semibold ${getActionColor(alert.action)}`}>
                        {alert.action.toUpperCase()}
                      </Badge>
                    )}
                    <span className="text-[10px] font-mono text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(alert.triggeredAt).toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                  {(alert.thresholdValue !== null || alert.actualValue !== null) && (
                    <div className="flex items-center gap-4 mt-2 text-[10px] font-mono text-muted-foreground">
                      {alert.thresholdValue !== null && (
                        <span>Threshold: <span className="text-foreground">{alert.thresholdValue?.toFixed(1)}%</span></span>
                      )}
                      {alert.actualValue !== null && (
                        <span>Actual: <span className={`font-semibold ${
                          (alert.actualValue ?? 0) > (alert.thresholdValue ?? 0) ? "text-critical" : "text-warning"
                        }`}>{alert.actualValue?.toFixed(1)}%</span></span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          );
        })}

        {displayed.length === 0 && (
          <Card className="p-12 text-center">
            <BellOff className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-foreground mb-1">
              {tab === "active" ? "No active alerts" : "No dismissed alerts"}
            </h3>
            <p className="text-xs text-muted-foreground">
              {tab === "active" ? "All clear - no threshold breaches detected" : "No alerts have been dismissed yet"}
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
