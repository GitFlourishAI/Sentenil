import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ImpactBadge, ConfidenceBadge, MaterialityBadge } from "@/components/impact-badge";
import { StatusIndicator } from "@/components/status-indicator";
import {
  Zap,
  Search,
  Filter,
  ExternalLink,
  Clock,
  TrendingUp,
  TrendingDown,
  ChevronDown,
  ChevronUp,
  FileText,
  ArrowUpDown,
} from "lucide-react";
import type { Catalyst, Sector, FinancialImpact, PortfolioPosition } from "@shared/schema";

function LoadingSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="flex gap-3">
        <Skeleton className="h-9 w-64 rounded-md" />
        <Skeleton className="h-9 w-32 rounded-md" />
        <Skeleton className="h-9 w-32 rounded-md" />
      </div>
      {[1, 2, 3, 4].map((i) => (
        <Skeleton key={i} className="h-32 rounded-md" />
      ))}
    </div>
  );
}

export default function CatalystsPage() {
  const [search, setSearch] = useState("");
  const [sectorFilter, setSectorFilter] = useState("all");
  const [sortBy, setSortBy] = useState<"impact" | "confidence" | "date">("impact");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const { data: catalysts, isLoading } = useQuery<Catalyst[]>({
    queryKey: ["/api/catalysts"],
  });
  const { data: sectors } = useQuery<Sector[]>({
    queryKey: ["/api/sectors"],
  });
  const { data: impacts } = useQuery<FinancialImpact[]>({
    queryKey: ["/api/financial-impacts"],
  });
  const { data: positions } = useQuery<PortfolioPosition[]>({
    queryKey: ["/api/positions"],
  });

  if (isLoading) return <LoadingSkeleton />;

  const sectorMap = new Map(sectors?.map((s) => [s.id, s]) ?? []);
  const positionMap = new Map(positions?.map((p) => [p.id, p]) ?? []);

  let filtered = catalysts ?? [];
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.sourceName.toLowerCase().includes(q)
    );
  }
  if (sectorFilter !== "all") {
    filtered = filtered.filter((c) => c.sectorId === sectorFilter);
  }

  filtered = [...filtered].sort((a, b) => {
    if (sortBy === "impact") return Math.abs(b.impactMagnitude) - Math.abs(a.impactMagnitude);
    if (sortBy === "confidence") return b.confidenceScore - a.confidenceScore;
    return new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime();
  });

  const getCatalystImpacts = (catalystId: string) =>
    impacts?.filter((i) => i.catalystId === catalystId) ?? [];

  return (
    <div className="p-4 space-y-4 overflow-auto h-full scrollbar-thin" data-testid="page-catalysts">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Catalyst Intelligence</h2>
          <p className="text-xs text-muted-foreground font-mono">
            {filtered.length} catalysts detected &middot; Ranked by impact magnitude
          </p>
        </div>
        <Badge variant="outline" className="font-mono text-[10px]">
          <StatusIndicator status="active" />
          <span className="ml-1.5">Scanning</span>
        </Badge>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search catalysts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-muted/30 border-border text-sm"
            data-testid="input-search-catalysts"
          />
        </div>
        <Select value={sectorFilter} onValueChange={setSectorFilter}>
          <SelectTrigger className="w-40 bg-muted/30" data-testid="select-sector-filter">
            <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
            <SelectValue placeholder="Sector" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sectors</SelectItem>
            {sectors?.map((s) => (
              <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
          <SelectTrigger className="w-40 bg-muted/30" data-testid="select-sort">
            <ArrowUpDown className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="impact">Impact</SelectItem>
            <SelectItem value="confidence">Confidence</SelectItem>
            <SelectItem value="date">Latest</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        {filtered.map((catalyst, index) => {
          const sector = sectorMap.get(catalyst.sectorId);
          const catalystImpacts = getCatalystImpacts(catalyst.id);
          const isExpanded = expandedId === catalyst.id;

          return (
            <Card key={catalyst.id} className="p-0" data-testid={`card-catalyst-${index}`}>
              <div
                className="p-4 cursor-pointer hover:bg-muted/20 transition-colors"
                onClick={() => setExpandedId(isExpanded ? null : catalyst.id)}
                data-testid={`button-expand-catalyst-${index}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <StatusIndicator status={catalyst.status} />
                      <h3 className="text-sm font-semibold text-foreground">{catalyst.title}</h3>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                      {catalyst.description}
                    </p>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className="text-[10px] font-mono" style={{
                        borderColor: sector?.color ? `${sector.color}40` : undefined,
                        color: sector?.color,
                      }}>
                        {sector?.name ?? "N/A"}
                      </Badge>
                      <Badge variant="outline" className="text-[10px] font-mono text-muted-foreground">
                        <Clock className="w-3 h-3 mr-1" />
                        {catalyst.timeHorizon}
                      </Badge>
                      <Badge variant="outline" className="text-[10px] font-mono text-muted-foreground">
                        {catalyst.shockType}
                      </Badge>
                      <Badge variant="outline" className="text-[10px] font-mono text-muted-foreground">
                        <FileText className="w-3 h-3 mr-1" />
                        {catalyst.sourceName}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                    <div className="flex items-center gap-2">
                      <ImpactBadge direction={catalyst.impactDirection} magnitude={catalyst.impactMagnitude} />
                      <ConfidenceBadge score={catalyst.confidenceScore} />
                    </div>
                    <span className="text-[10px] font-mono text-muted-foreground">
                      {new Date(catalyst.detectedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                </div>
              </div>

              {isExpanded && (
                <div className="border-t border-border p-4 bg-muted/10">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-[10px] font-mono tracking-wider text-muted-foreground mb-2">EVIDENCE SUMMARY</h4>
                      <p className="text-xs text-foreground leading-relaxed">{catalyst.evidenceSummary}</p>
                      {catalyst.sourceUrl && (
                        <a
                          href={catalyst.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-primary flex items-center gap-1 mt-2 hover:underline"
                          data-testid="link-source"
                        >
                          <ExternalLink className="w-3 h-3" /> View Source
                        </a>
                      )}
                    </div>
                    <div>
                      <h4 className="text-[10px] font-mono tracking-wider text-muted-foreground mb-2">
                        AFFECTED POSITIONS ({catalystImpacts.length})
                      </h4>
                      {catalystImpacts.length > 0 ? (
                        <div className="space-y-1.5">
                          {catalystImpacts.map((impact) => {
                            const pos = positionMap.get(impact.positionId);
                            return (
                              <div key={impact.id} className="flex items-center justify-between gap-2 p-2 rounded-md bg-muted/30">
                                <div>
                                  <span className="text-xs font-mono font-semibold">{pos?.ticker ?? "N/A"}</span>
                                  <span className="text-[10px] text-muted-foreground ml-2">{pos?.companyName}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <MaterialityBadge level={impact.materialityLevel} />
                                  {impact.valuationDelta !== null && (
                                    <span className={`text-xs font-mono font-semibold ${
                                      (impact.valuationDelta ?? 0) >= 0 ? "text-success" : "text-critical"
                                    }`}>
                                      {(impact.valuationDelta ?? 0) >= 0 ? "+" : ""}{impact.valuationDelta?.toFixed(1)}%
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground">No direct position impacts mapped</p>
                      )}
                    </div>
                  </div>

                  {catalystImpacts.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-[10px] font-mono tracking-wider text-muted-foreground mb-2">FINANCIAL IMPACT BREAKDOWN</h4>
                      <div className="grid grid-cols-7 gap-1">
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-muted/20 rounded-md text-center">
                          <div className="mb-1">Revenue</div>
                          {catalystImpacts[0]?.revenueImpact !== null ? (
                            <div className={`text-sm font-semibold ${
                              catalystImpacts[0]?.revenueDirection === "positive" ? "text-success" : "text-critical"
                            }`}>
                              {catalystImpacts[0]?.revenueDirection === "positive" ? "+" : "-"}{Math.abs(catalystImpacts[0]?.revenueImpact ?? 0).toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-muted/20 rounded-md text-center">
                          <div className="mb-1">Costs</div>
                          {catalystImpacts[0]?.costImpact !== null ? (
                            <div className={`text-sm font-semibold ${
                              catalystImpacts[0]?.costDirection === "positive" ? "text-success" : "text-critical"
                            }`}>
                              {catalystImpacts[0]?.costDirection === "positive" ? "+" : "-"}{Math.abs(catalystImpacts[0]?.costImpact ?? 0).toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-muted/20 rounded-md text-center">
                          <div className="mb-1">EBITDA</div>
                          {catalystImpacts[0]?.ebitdaImpact !== null ? (
                            <div className={`text-sm font-semibold ${
                              catalystImpacts[0]?.ebitdaDirection === "positive" ? "text-success" : "text-critical"
                            }`}>
                              {catalystImpacts[0]?.ebitdaDirection === "positive" ? "+" : "-"}{Math.abs(catalystImpacts[0]?.ebitdaImpact ?? 0).toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-muted/20 rounded-md text-center">
                          <div className="mb-1">CapEx</div>
                          {catalystImpacts[0]?.capexImpact !== null ? (
                            <div className={`text-sm font-semibold ${
                              catalystImpacts[0]?.capexDirection === "positive" ? "text-success" : "text-critical"
                            }`}>
                              {catalystImpacts[0]?.capexDirection === "positive" ? "+" : "-"}{Math.abs(catalystImpacts[0]?.capexImpact ?? 0).toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-muted/20 rounded-md text-center">
                          <div className="mb-1">W.Capital</div>
                          {catalystImpacts[0]?.workingCapitalImpact !== null ? (
                            <div className={`text-sm font-semibold ${
                              catalystImpacts[0]?.workingCapitalDirection === "positive" ? "text-success" : "text-critical"
                            }`}>
                              {catalystImpacts[0]?.workingCapitalDirection === "positive" ? "+" : "-"}{Math.abs(catalystImpacts[0]?.workingCapitalImpact ?? 0).toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-muted/20 rounded-md text-center">
                          <div className="mb-1">Debt</div>
                          {catalystImpacts[0]?.debtImpact !== null ? (
                            <div className={`text-sm font-semibold ${
                              catalystImpacts[0]?.debtDirection === "positive" ? "text-success" : "text-critical"
                            }`}>
                              {catalystImpacts[0]?.debtDirection === "positive" ? "+" : "-"}{Math.abs(catalystImpacts[0]?.debtImpact ?? 0).toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground p-2 bg-primary/10 rounded-md text-center border border-primary/20">
                          <div className="mb-1 text-primary">Val. Delta</div>
                          {catalystImpacts[0]?.valuationDelta !== null ? (
                            <div className={`text-sm font-semibold ${
                              (catalystImpacts[0]?.valuationDelta ?? 0) >= 0 ? "text-success" : "text-critical"
                            }`}>
                              {(catalystImpacts[0]?.valuationDelta ?? 0) >= 0 ? "+" : ""}{catalystImpacts[0]?.valuationDelta?.toFixed(1)}%
                            </div>
                          ) : <div className="text-sm text-muted-foreground">--</div>}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>
          );
        })}

        {filtered.length === 0 && (
          <Card className="p-12 text-center">
            <Zap className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-foreground mb-1">No catalysts found</h3>
            <p className="text-xs text-muted-foreground">
              {search || sectorFilter !== "all" ? "Try adjusting your filters" : "No catalysts have been detected yet"}
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
