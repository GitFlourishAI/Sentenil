import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MetricCard } from "@/components/metric-card";
import {
  Briefcase,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  TrendingUp,
  Globe,
  DollarSign,
} from "lucide-react";
import type { PortfolioPosition, Sector, FinancialImpact } from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Treemap,
} from "recharts";

function LoadingSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-4 gap-3">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-24 rounded-md" />
        ))}
      </div>
      <Skeleton className="h-64 rounded-md" />
      <Skeleton className="h-48 rounded-md" />
    </div>
  );
}

function TreemapContent(props: any) {
  const { x, y, width, height, name, pnlPercent } = props;
  if (width < 40 || height < 30) return null;

  return (
    <g>
      <rect
        x={x}
        y={y}
        width={width}
        height={height}
        rx={4}
        style={{
          fill: (pnlPercent ?? 0) >= 0 ? "hsl(142, 71%, 45%)" : "hsl(0, 72%, 51%)",
          fillOpacity: Math.min(0.15 + Math.abs(pnlPercent ?? 0) / 20, 0.8),
          stroke: "hsl(215, 19%, 15%)",
          strokeWidth: 1,
        }}
      />
      <text
        x={x + width / 2}
        y={y + height / 2 - 6}
        textAnchor="middle"
        fill="hsl(213, 31%, 91%)"
        fontSize={width > 60 ? 11 : 9}
        fontFamily="monospace"
        fontWeight={600}
      >
        {name}
      </text>
      <text
        x={x + width / 2}
        y={y + height / 2 + 8}
        textAnchor="middle"
        fill={(pnlPercent ?? 0) >= 0 ? "hsl(142, 71%, 45%)" : "hsl(0, 72%, 51%)"}
        fontSize={9}
        fontFamily="monospace"
      >
        {(pnlPercent ?? 0) >= 0 ? "+" : ""}{(pnlPercent ?? 0).toFixed(1)}%
      </text>
    </g>
  );
}

export default function PortfolioPage() {
  const [search, setSearch] = useState("");
  const [sectorFilter, setSectorFilter] = useState("all");
  const [view, setView] = useState("table");

  const { data: positions, isLoading } = useQuery<PortfolioPosition[]>({
    queryKey: ["/api/positions"],
  });
  const { data: sectors } = useQuery<Sector[]>({
    queryKey: ["/api/sectors"],
  });
  const { data: impacts } = useQuery<FinancialImpact[]>({
    queryKey: ["/api/financial-impacts"],
  });

  if (isLoading) return <LoadingSkeleton />;

  const sectorMap = new Map(sectors?.map((s) => [s.id, s]) ?? []);

  const totalValue = positions?.reduce((s, p) => s + p.marketValue, 0) ?? 0;
  const totalPnl = positions?.reduce((s, p) => s + p.pnl, 0) ?? 0;
  const totalCost = positions?.reduce((s, p) => s + (p.avgCost * p.shares), 0) ?? 0;
  const totalReturn = totalCost > 0 ? (totalPnl / totalCost) * 100 : 0;
  const avgBeta = positions && positions.length > 0
    ? positions.reduce((s, p) => s + p.beta * p.weight, 0) / positions.reduce((s, p) => s + p.weight, 0)
    : 0;

  const impactsByPosition = new Map<string, FinancialImpact[]>();
  impacts?.forEach((i) => {
    const existing = impactsByPosition.get(i.positionId) ?? [];
    existing.push(i);
    impactsByPosition.set(i.positionId, existing);
  });

  const portfolioDelta = positions?.reduce((s, p) => {
    const posImpacts = impactsByPosition.get(p.id) ?? [];
    const avgDelta = posImpacts.length > 0
      ? posImpacts.reduce((ss, i) => ss + (i.valuationDelta ?? 0), 0) / posImpacts.length
      : 0;
    return s + avgDelta * (p.weight / 100);
  }, 0) ?? 0;

  let filtered = positions ?? [];
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (p) => p.ticker.toLowerCase().includes(q) || p.companyName.toLowerCase().includes(q)
    );
  }
  if (sectorFilter !== "all") {
    filtered = filtered.filter((p) => p.sectorId === sectorFilter);
  }

  const formatCurrency = (val: number) => {
    if (Math.abs(val) >= 1e9) return `$${(val / 1e9).toFixed(2)}B`;
    if (Math.abs(val) >= 1e6) return `$${(val / 1e6).toFixed(1)}M`;
    if (Math.abs(val) >= 1e3) return `$${(val / 1e3).toFixed(0)}K`;
    return `$${val.toFixed(0)}`;
  };

  const treemapData = filtered.map((p) => ({
    name: p.ticker,
    size: p.marketValue,
    pnlPercent: p.pnlPercent,
  }));

  const regionData = positions?.reduce((acc, p) => {
    acc[p.region] = (acc[p.region] || 0) + p.marketValue;
    return acc;
  }, {} as Record<string, number>) ?? {};

  const regionBarData = Object.entries(regionData).map(([region, value]) => ({
    region,
    value,
    pct: (value / totalValue) * 100,
  }));

  return (
    <div className="p-4 space-y-4 overflow-auto h-full scrollbar-thin" data-testid="page-portfolio">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Portfolio Monitor</h2>
          <p className="text-xs text-muted-foreground font-mono">
            {positions?.length ?? 0} positions &middot; Aggregated exposure analysis
          </p>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-3" data-testid="portfolio-metrics">
        <MetricCard
          label="Total AUM"
          value={formatCurrency(totalValue)}
          icon={<DollarSign className="w-4 h-4" />}
          accentColor="hsl(190, 100%, 50%)"
          testId="metric-total-aum"
        />
        <MetricCard
          label="Total P&L"
          value={formatCurrency(totalPnl)}
          trend={totalPnl >= 0 ? "up" : "down"}
          trendValue={`${totalReturn >= 0 ? "+" : ""}${totalReturn.toFixed(2)}%`}
          accentColor={totalPnl >= 0 ? "hsl(142, 71%, 45%)" : "hsl(0, 72%, 51%)"}
          testId="metric-total-pnl"
        />
        <MetricCard
          label="Portfolio Beta"
          value={avgBeta.toFixed(2)}
          subValue="Weighted average"
          accentColor="hsl(38, 92%, 50%)"
          testId="metric-portfolio-beta"
        />
        <MetricCard
          label="Expected Delta"
          value={`${portfolioDelta >= 0 ? "+" : ""}${portfolioDelta.toFixed(2)}%`}
          subValue="Catalyst-driven"
          trend={portfolioDelta >= 0 ? "up" : "down"}
          trendValue={Math.abs(portfolioDelta) > 1 ? "Material" : "Minimal"}
          accentColor="hsl(213, 24%, 40%)"
          testId="metric-expected-delta"
        />
        <MetricCard
          label="Regions"
          value={String(Object.keys(regionData).length)}
          subValue="Geographic spread"
          icon={<Globe className="w-4 h-4" />}
          testId="metric-regions"
        />
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search positions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-muted/30 border-border text-sm"
            data-testid="input-search-positions"
          />
        </div>
        <Select value={sectorFilter} onValueChange={setSectorFilter}>
          <SelectTrigger className="w-40 bg-muted/30" data-testid="select-sector-filter">
            <SelectValue placeholder="All Sectors" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sectors</SelectItem>
            {sectors?.map((s) => (
              <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Tabs value={view} onValueChange={setView}>
          <TabsList className="bg-muted/30">
            <TabsTrigger value="table" className="text-xs" data-testid="tab-table-view">Table</TabsTrigger>
            <TabsTrigger value="treemap" className="text-xs" data-testid="tab-treemap-view">Treemap</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {view === "table" ? (
        <Card className="p-0" data-testid="card-positions-table">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">TICKER</th>
                  <th className="text-left px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">COMPANY</th>
                  <th className="text-left px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">SECTOR</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">WEIGHT</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">PRICE</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">MKT VALUE</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">P&L</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">P&L %</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">BETA</th>
                  <th className="text-right px-4 py-3 text-[10px] font-mono tracking-wider text-muted-foreground">VAL DELTA</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((pos, i) => {
                  const sector = sectorMap.get(pos.sectorId);
                  const posImpacts = impactsByPosition.get(pos.id) ?? [];
                  const avgDelta = posImpacts.length > 0
                    ? posImpacts.reduce((s, imp) => s + (imp.valuationDelta ?? 0), 0) / posImpacts.length
                    : 0;

                  return (
                    <tr key={pos.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors" data-testid={`row-position-${i}`}>
                      <td className="px-4 py-3">
                        <span className="font-mono font-semibold text-foreground">{pos.ticker}</span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs max-w-[140px] truncate">{pos.companyName}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="text-[10px] font-mono" style={{
                          borderColor: sector?.color ? `${sector.color}40` : undefined,
                          color: sector?.color,
                        }}>
                          {sector?.name ?? "N/A"}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-xs">{pos.weight.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right font-mono text-xs">${pos.currentPrice.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right font-mono text-xs">{formatCurrency(pos.marketValue)}</td>
                      <td className={`px-4 py-3 text-right font-mono text-xs ${pos.pnl >= 0 ? "text-success" : "text-critical"}`}>
                        {pos.pnl >= 0 ? "+" : ""}{formatCurrency(pos.pnl)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className={`flex items-center justify-end gap-1 font-mono text-xs ${pos.pnlPercent >= 0 ? "text-success" : "text-critical"}`}>
                          {pos.pnlPercent >= 0 ? (
                            <ArrowUpRight className="w-3 h-3" />
                          ) : (
                            <ArrowDownRight className="w-3 h-3" />
                          )}
                          {pos.pnlPercent >= 0 ? "+" : ""}{pos.pnlPercent.toFixed(2)}%
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-xs">{pos.beta.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right">
                        {avgDelta !== 0 ? (
                          <span className={`font-mono text-xs font-semibold ${avgDelta >= 0 ? "text-success" : "text-critical"}`}>
                            {avgDelta >= 0 ? "+" : ""}{avgDelta.toFixed(1)}%
                          </span>
                        ) : (
                          <span className="font-mono text-xs text-muted-foreground">--</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && (
            <div className="text-center py-12">
              <Briefcase className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No positions match your filters</p>
            </div>
          )}
        </Card>
      ) : (
        <Card className="p-4" data-testid="card-treemap">
          <h3 className="text-sm font-semibold mb-3">Position Heatmap (by Market Value)</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <Treemap
                data={treemapData}
                dataKey="size"
                aspectRatio={4 / 3}
                content={<TreemapContent />}
              />
            </ResponsiveContainer>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4" data-testid="card-region-exposure">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Regional Exposure</h3>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regionBarData} barSize={40} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(215, 19%, 15%)" horizontal={false} />
                <XAxis
                  type="number"
                  tick={{ fontSize: 10, fill: "hsl(213, 18%, 55%)", fontFamily: "monospace" }}
                  axisLine={{ stroke: "hsl(215, 19%, 15%)" }}
                  tickLine={false}
                  tickFormatter={(v: number) => `${v.toFixed(0)}%`}
                />
                <YAxis
                  dataKey="region"
                  type="category"
                  tick={{ fontSize: 10, fill: "hsl(213, 18%, 55%)", fontFamily: "monospace" }}
                  axisLine={{ stroke: "hsl(215, 19%, 15%)" }}
                  tickLine={false}
                  width={80}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(215, 25%, 10%)",
                    border: "1px solid hsl(215, 19%, 15%)",
                    borderRadius: "6px",
                    fontSize: "11px",
                    fontFamily: "monospace",
                    color: "hsl(213, 31%, 91%)",
                  }}
                  formatter={(value: number) => [`${value.toFixed(1)}%`, "Exposure"]}
                />
                <Bar dataKey="pct" fill="hsl(190, 100%, 50%)" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-4" data-testid="card-sector-weights">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Sector Weight Distribution</h3>
          </div>
          <div className="space-y-2 max-h-48 overflow-auto scrollbar-thin">
            {sectors?.map((sector) => {
              const sectorPositions = positions?.filter((p) => p.sectorId === sector.id) ?? [];
              const sectorWeight = sectorPositions.reduce((s, p) => s + p.weight, 0);
              const sectorPnl = sectorPositions.reduce((s, p) => s + p.pnlPercent * p.weight, 0) / (sectorWeight || 1);

              return (
                <div key={sector.id} className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: sector.color }} />
                  <span className="text-xs text-muted-foreground flex-1 min-w-0 truncate">{sector.name}</span>
                  <div className="w-32 h-1.5 bg-muted/30 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${Math.min(sectorWeight, 100)}%`, background: sector.color }}
                    />
                  </div>
                  <span className="text-xs font-mono text-foreground w-12 text-right">{sectorWeight.toFixed(1)}%</span>
                  <span className={`text-xs font-mono w-14 text-right ${sectorPnl >= 0 ? "text-success" : "text-critical"}`}>
                    {sectorPnl >= 0 ? "+" : ""}{sectorPnl.toFixed(1)}%
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
