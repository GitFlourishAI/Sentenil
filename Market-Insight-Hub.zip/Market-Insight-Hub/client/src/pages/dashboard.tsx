import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { MetricCard } from "@/components/metric-card";
import { ImpactBadge, ConfidenceBadge } from "@/components/impact-badge";
import { StatusIndicator } from "@/components/status-indicator";
import {
  Activity,
  TrendingDown,
  Shield,
  Zap,
  BarChart3,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { Link } from "wouter";
import type { Catalyst, PortfolioPosition, Alert, FinancialImpact, Sector } from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts";

function LoadingSkeleton() {
  return (
    <div className="space-y-4 p-6">
      <div className="grid grid-cols-4 gap-3">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-24 rounded-md" />
        ))}
      </div>
      <div className="grid grid-cols-3 gap-3">
        <Skeleton className="h-64 col-span-2 rounded-md" />
        <Skeleton className="h-64 rounded-md" />
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: catalysts, isLoading: loadingCatalysts } = useQuery<Catalyst[]>({
    queryKey: ["/api/catalysts"],
  });
  const { data: positions, isLoading: loadingPositions } = useQuery<PortfolioPosition[]>({
    queryKey: ["/api/positions"],
  });
  const { data: alerts, isLoading: loadingAlerts } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });
  const { data: impacts, isLoading: loadingImpacts } = useQuery<FinancialImpact[]>({
    queryKey: ["/api/financial-impacts"],
  });
  const { data: sectors } = useQuery<Sector[]>({
    queryKey: ["/api/sectors"],
  });

  const isLoading = loadingCatalysts || loadingPositions || loadingAlerts || loadingImpacts;

  if (isLoading) return <LoadingSkeleton />;

  const totalPortfolioValue = positions?.reduce((s, p) => s + p.marketValue, 0) ?? 0;
  const totalPnl = positions?.reduce((s, p) => s + p.pnl, 0) ?? 0;
  const totalPnlPct = totalPortfolioValue > 0 ? (totalPnl / (totalPortfolioValue - totalPnl)) * 100 : 0;
  const activeCatalysts = catalysts?.filter((c) => c.status === "active") ?? [];
  const criticalAlerts = alerts?.filter((a) => a.severity === "critical" && !a.isDismissed) ?? [];
  const avgConfidence = activeCatalysts.length > 0
    ? activeCatalysts.reduce((s, c) => s + c.confidenceScore, 0) / activeCatalysts.length
    : 0;

  const avgImpact = impacts && impacts.length > 0
    ? impacts.reduce((s, i) => s + Math.abs(i.valuationDelta ?? 0), 0) / impacts.length
    : 0;

  const topCatalysts = [...(activeCatalysts ?? [])]
    .sort((a, b) => Math.abs(b.impactMagnitude) - Math.abs(a.impactMagnitude))
    .slice(0, 5);

  const sectorMap = new Map(sectors?.map((s) => [s.id, s]) ?? []);

  const sectorExposure = positions?.reduce((acc, p) => {
    const sName = sectorMap.get(p.sectorId)?.name ?? "Other";
    acc[sName] = (acc[sName] || 0) + p.marketValue;
    return acc;
  }, {} as Record<string, number>) ?? {};

  const sectorColors = ["#00D4FF", "#3FB950", "#D29922", "#F85149", "#1E3A5F", "#6E40C9", "#8B949E"];
  const pieData = Object.entries(sectorExposure).map(([name, value], i) => ({
    name,
    value,
    color: sectorColors[i % sectorColors.length],
  }));

  const impactByBlock = [
    { block: "Revenue", value: impacts?.reduce((s, i) => s + Math.abs(i.revenueImpact ?? 0), 0) ?? 0 },
    { block: "Costs", value: impacts?.reduce((s, i) => s + Math.abs(i.costImpact ?? 0), 0) ?? 0 },
    { block: "EBITDA", value: impacts?.reduce((s, i) => s + Math.abs(i.ebitdaImpact ?? 0), 0) ?? 0 },
    { block: "CapEx", value: impacts?.reduce((s, i) => s + Math.abs(i.capexImpact ?? 0), 0) ?? 0 },
    { block: "Debt", value: impacts?.reduce((s, i) => s + Math.abs(i.debtImpact ?? 0), 0) ?? 0 },
  ];

  const formatCurrency = (val: number) => {
    if (Math.abs(val) >= 1e9) return `$${(val / 1e9).toFixed(1)}B`;
    if (Math.abs(val) >= 1e6) return `$${(val / 1e6).toFixed(1)}M`;
    if (Math.abs(val) >= 1e3) return `$${(val / 1e3).toFixed(0)}K`;
    return `$${val.toFixed(0)}`;
  };

  return (
    <div className="p-4 space-y-4 scrollbar-thin overflow-auto h-full" data-testid="page-dashboard">
      <div className="flex items-center justify-between gap-2 mb-1">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Command Center</h2>
          <p className="text-xs text-muted-foreground font-mono">
            Real-time portfolio intelligence &middot; {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <StatusIndicator status="active" label="Live Feed" />
          <Badge variant="outline" className="font-mono text-[10px]">
            {positions?.length ?? 0} Positions
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3" data-testid="metrics-grid">
        <MetricCard
          label="Portfolio Value"
          value={formatCurrency(totalPortfolioValue)}
          trend={totalPnl >= 0 ? "up" : "down"}
          trendValue={`${totalPnlPct >= 0 ? "+" : ""}${totalPnlPct.toFixed(2)}%`}
          accentColor="hsl(190, 100%, 50%)"
          icon={<BarChart3 className="w-4 h-4" />}
          testId="metric-portfolio-value"
        />
        <MetricCard
          label="Active Catalysts"
          value={String(activeCatalysts.length)}
          subValue={`${avgConfidence > 0 ? Math.round(avgConfidence * 100) : 0}% avg confidence`}
          accentColor="hsl(38, 92%, 50%)"
          icon={<Zap className="w-4 h-4" />}
          testId="metric-active-catalysts"
        />
        <MetricCard
          label="Avg Impact Delta"
          value={`${avgImpact.toFixed(1)}%`}
          subValue="Valuation sensitivity"
          trend={avgImpact > 3 ? "down" : "neutral"}
          trendValue={avgImpact > 3 ? "Elevated" : "Normal"}
          accentColor="hsl(142, 71%, 45%)"
          icon={<Activity className="w-4 h-4" />}
          testId="metric-avg-impact"
        />
        <MetricCard
          label="Critical Alerts"
          value={String(criticalAlerts.length)}
          subValue="Action required"
          accentColor={criticalAlerts.length > 0 ? "hsl(0, 72%, 51%)" : "hsl(215, 20%, 25%)"}
          icon={<AlertTriangle className="w-4 h-4" />}
          testId="metric-critical-alerts"
        />
      </div>

      <div className="grid grid-cols-12 gap-3">
        <Card className="col-span-8 p-4" data-testid="card-top-catalysts">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Top Catalysts by Impact</h3>
            </div>
            <Link href="/catalysts" className="text-xs text-primary font-mono flex items-center gap-1 hover:underline" data-testid="link-view-all-catalysts">
              View All <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="space-y-1">
            <div className="grid grid-cols-12 gap-2 px-3 py-1.5 text-[10px] font-mono text-muted-foreground tracking-wider">
              <span className="col-span-4">CATALYST</span>
              <span className="col-span-2">SECTOR</span>
              <span className="col-span-1">HORIZON</span>
              <span className="col-span-2">IMPACT</span>
              <span className="col-span-1">CONF</span>
              <span className="col-span-2">DIRECTION</span>
            </div>
            {topCatalysts.map((c, i) => {
              const sector = sectorMap.get(c.sectorId);
              return (
                <div
                  key={c.id}
                  className="grid grid-cols-12 gap-2 items-center px-3 py-2.5 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors"
                  data-testid={`row-catalyst-${i}`}
                >
                  <div className="col-span-4">
                    <p className="text-sm font-medium text-foreground truncate">{c.title}</p>
                    <p className="text-[10px] text-muted-foreground font-mono truncate">{c.sourceName}</p>
                  </div>
                  <div className="col-span-2">
                    <Badge variant="outline" className="text-[10px] font-mono" style={{
                      borderColor: sector?.color ? `${sector.color}40` : undefined,
                      color: sector?.color,
                    }}>
                      {sector?.name ?? "N/A"}
                    </Badge>
                  </div>
                  <div className="col-span-1">
                    <span className="text-xs font-mono text-muted-foreground">{c.timeHorizon}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-sm font-mono font-semibold text-foreground">
                      {Math.abs(c.impactMagnitude).toFixed(1)}%
                    </span>
                  </div>
                  <div className="col-span-1">
                    <ConfidenceBadge score={c.confidenceScore} />
                  </div>
                  <div className="col-span-2">
                    <ImpactBadge direction={c.impactDirection} />
                  </div>
                </div>
              );
            })}
            {topCatalysts.length === 0 && (
              <div className="text-center py-8 text-sm text-muted-foreground">
                No active catalysts detected
              </div>
            )}
          </div>
        </Card>

        <Card className="col-span-4 p-4" data-testid="card-sector-exposure">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Sector Exposure</h3>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "hsl(215, 25%, 10%)",
                    border: "1px solid hsl(215, 19%, 15%)",
                    borderRadius: "6px",
                    fontSize: "11px",
                    fontFamily: "monospace",
                    color: "hsl(213, 31%, 91%)",
                  }}
                  formatter={(value: number) => formatCurrency(value)}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-1.5 mt-2">
            {pieData.map((entry) => (
              <div key={entry.name} className="flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
                  <span className="text-muted-foreground">{entry.name}</span>
                </div>
                <span className="font-mono text-foreground">
                  {((entry.value / totalPortfolioValue) * 100).toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-12 gap-3">
        <Card className="col-span-5 p-4" data-testid="card-impact-blocks">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Financial Impact by Block</h3>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={impactByBlock} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(215, 19%, 15%)" />
                <XAxis
                  dataKey="block"
                  tick={{ fontSize: 10, fill: "hsl(213, 18%, 55%)", fontFamily: "monospace" }}
                  axisLine={{ stroke: "hsl(215, 19%, 15%)" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "hsl(213, 18%, 55%)", fontFamily: "monospace" }}
                  axisLine={{ stroke: "hsl(215, 19%, 15%)" }}
                  tickLine={false}
                  tickFormatter={(v: number) => `${v.toFixed(0)}%`}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(215, 25%, 10%)",
                    border: "1px solid hsl(215, 19%, 15%)",
                    borderRadius: "6px",
                    fontSize: "11px",
                    fontFamily: "monospace",
                    color: "hsl(213, 31%, 91%)",
                  }}
                  formatter={(value: number) => [`${value.toFixed(1)}%`, "Impact"]}
                />
                <Bar dataKey="value" fill="hsl(190, 100%, 50%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="col-span-4 p-4" data-testid="card-recent-alerts">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-warning" />
              <h3 className="text-sm font-semibold">Recent Alerts</h3>
            </div>
            <Link href="/alerts" className="text-xs text-primary font-mono flex items-center gap-1 hover:underline" data-testid="link-view-all-alerts">
              View All <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="space-y-2 max-h-48 overflow-auto scrollbar-thin">
            {alerts?.filter(a => !a.isDismissed).slice(0, 5).map((alert) => (
              <div key={alert.id} className="flex items-start gap-2 p-2 rounded-md bg-muted/30">
                <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                  alert.severity === "critical" ? "bg-critical" :
                  alert.severity === "high" ? "bg-warning" : "bg-primary"
                }`} />
                <div className="min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{alert.title}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{alert.message}</p>
                </div>
              </div>
            ))}
            {(!alerts || alerts.filter(a => !a.isDismissed).length === 0) && (
              <div className="text-center py-6 text-sm text-muted-foreground">
                No active alerts
              </div>
            )}
          </div>
        </Card>

        <Card className="col-span-3 p-4" data-testid="card-portfolio-movers">
          <div className="flex items-center gap-2 mb-3">
            <TrendingDown className="w-4 h-4 text-critical" />
            <h3 className="text-sm font-semibold">Top Movers</h3>
          </div>
          <div className="space-y-2">
            {positions?.sort((a, b) => Math.abs(b.pnlPercent) - Math.abs(a.pnlPercent)).slice(0, 5).map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-2 py-1">
                <div>
                  <p className="text-xs font-mono font-semibold text-foreground">{p.ticker}</p>
                  <p className="text-[10px] text-muted-foreground truncate max-w-[80px]">{p.companyName}</p>
                </div>
                <div className="text-right">
                  <p className={`text-xs font-mono font-semibold ${p.pnlPercent >= 0 ? "text-success" : "text-critical"}`}>
                    {p.pnlPercent >= 0 ? "+" : ""}{p.pnlPercent.toFixed(2)}%
                  </p>
                  <div className="flex items-center justify-end">
                    {p.pnlPercent >= 0 ? (
                      <ArrowUpRight className="w-3 h-3 text-success" />
                    ) : (
                      <ArrowDownRight className="w-3 h-3 text-critical" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
